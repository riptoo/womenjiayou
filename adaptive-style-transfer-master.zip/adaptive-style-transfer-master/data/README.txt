Place here all the data you want to process.
This includes both style samples and target images you want to stylize.
Dataset of style images for Van-Gogh you can download from https://drive.google.com/drive/folders/1yUgP4s6tgOC91fcL94cN2ocOqk7JUol9?usp=sharing .
Also sample photographs can be downloaded from the same folder.
