Here you store models checkpoints, training logs and all intermediate results.
Download pretrained models from https://drive.google.com/drive/folders/1SrWcmpZXXZ2gh821a0MUApNKO8Rm69ku?usp=sharing
and extract them to this folder.



